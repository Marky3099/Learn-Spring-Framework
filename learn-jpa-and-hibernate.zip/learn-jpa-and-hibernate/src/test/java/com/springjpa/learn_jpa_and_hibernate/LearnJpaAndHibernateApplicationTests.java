package com.springjpa.learn_jpa_and_hibernate;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LearnJpaAndHibernateApplicationTests {

	@Test
	void contextLoads() {
	}

}
